#pragma once

class Tablero {
    
public:
    Tablero();
    ~Tablero();


};