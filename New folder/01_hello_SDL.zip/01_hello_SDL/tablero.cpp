#include "tablero.h"

#include <iostream>

Tablero::Tablero(){
    printf( "tablero creado!\n" );
}

Tablero::~Tablero(){

}
